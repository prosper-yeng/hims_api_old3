from django.apps import AppConfig


class SampleTypeConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "sample_type"
